/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author a1818058
 */
@Entity
@Table(name = "hq")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Hq.findAll", query = "SELECT h FROM Hq h")
    , @NamedQuery(name = "Hq.findByIdHq", query = "SELECT h FROM Hq h WHERE h.idHq = :idHq")
    , @NamedQuery(name = "Hq.findByNomeHq", query = "SELECT h FROM Hq h WHERE h.nomeHq = :nomeHq")
    , @NamedQuery(name = "Hq.findByGeneroHq", query = "SELECT h FROM Hq h WHERE h.generoHq = :generoHq")})
public class Hq implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_hq")
    private Integer idHq;
    @Column(name = "nome_hq")
    private String nomeHq;
    @Column(name = "genero_hq")
    private String generoHq;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "hq")
    private List<UsuarioLeHq> usuarioLeHqList;

    public Hq() {
    }

    public Hq(Integer idHq) {
        this.idHq = idHq;
    }

    public Integer getIdHq() {
        return idHq;
    }

    public void setIdHq(Integer idHq) {
        this.idHq = idHq;
    }

    public String getNomeHq() {
        return nomeHq;
    }

    public void setNomeHq(String nomeHq) {
        this.nomeHq = nomeHq;
    }

    public String getGeneroHq() {
        return generoHq;
    }

    public void setGeneroHq(String generoHq) {
        this.generoHq = generoHq;
    }

    @XmlTransient
    public List<UsuarioLeHq> getUsuarioLeHqList() {
        return usuarioLeHqList;
    }

    public void setUsuarioLeHqList(List<UsuarioLeHq> usuarioLeHqList) {
        this.usuarioLeHqList = usuarioLeHqList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHq != null ? idHq.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Hq)) {
            return false;
        }
        Hq other = (Hq) object;
        if ((this.idHq == null && other.idHq != null) || (this.idHq != null && !this.idHq.equals(other.idHq))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Hq[ idHq=" + idHq + " ]";
    }
    
}
