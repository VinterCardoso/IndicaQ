/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author a1818058
 */
@Entity
@Table(name = "usuario")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Usuario.findAll", query = "SELECT u FROM Usuario u")
    , @NamedQuery(name = "Usuario.findByIdUsuario", query = "SELECT u FROM Usuario u WHERE u.idUsuario = :idUsuario")
    , @NamedQuery(name = "Usuario.findByNomeUsuario", query = "SELECT u FROM Usuario u WHERE u.nomeUsuario = :nomeUsuario")
    , @NamedQuery(name = "Usuario.findByDataNascUsuario", query = "SELECT u FROM Usuario u WHERE u.dataNascUsuario = :dataNascUsuario")
    , @NamedQuery(name = "Usuario.findByGeneroFavoritoUsuario", query = "SELECT u FROM Usuario u WHERE u.generoFavoritoUsuario = :generoFavoritoUsuario")})
public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_usuario")
    private Integer idUsuario;
    @Column(name = "nome_usuario")
    private String nomeUsuario;
    @Column(name = "data_nasc_usuario")
    @Temporal(TemporalType.DATE)
    private Date dataNascUsuario;
    @Column(name = "genero_favorito_usuario")
    private String generoFavoritoUsuario;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "usuario")
    private List<UsuarioLeHq> usuarioLeHqList;
    @JoinColumn(name = "avaliacao_id_avaliacao", referencedColumnName = "id_avaliacao")
    @ManyToOne(optional = false)
    private Avaliacao avaliacaoIdAvaliacao;

    public Usuario() {
    }

    public Usuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public Date getDataNascUsuario() {
        return dataNascUsuario;
    }

    public void setDataNascUsuario(Date dataNascUsuario) {
        this.dataNascUsuario = dataNascUsuario;
    }

    public String getGeneroFavoritoUsuario() {
        return generoFavoritoUsuario;
    }

    public void setGeneroFavoritoUsuario(String generoFavoritoUsuario) {
        this.generoFavoritoUsuario = generoFavoritoUsuario;
    }

    @XmlTransient
    public List<UsuarioLeHq> getUsuarioLeHqList() {
        return usuarioLeHqList;
    }

    public void setUsuarioLeHqList(List<UsuarioLeHq> usuarioLeHqList) {
        this.usuarioLeHqList = usuarioLeHqList;
    }

    public Avaliacao getAvaliacaoIdAvaliacao() {
        return avaliacaoIdAvaliacao;
    }

    public void setAvaliacaoIdAvaliacao(Avaliacao avaliacaoIdAvaliacao) {
        this.avaliacaoIdAvaliacao = avaliacaoIdAvaliacao;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idUsuario != null ? idUsuario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usuario)) {
            return false;
        }
        Usuario other = (Usuario) object;
        if ((this.idUsuario == null && other.idUsuario != null) || (this.idUsuario != null && !this.idUsuario.equals(other.idUsuario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Usuario[ idUsuario=" + idUsuario + " ]";
    }
    
}
