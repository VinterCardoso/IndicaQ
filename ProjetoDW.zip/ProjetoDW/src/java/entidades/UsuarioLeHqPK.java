/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author a1818058
 */
@Embeddable
public class UsuarioLeHqPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "usuario_id_usuario")
    private int usuarioIdUsuario;
    @Basic(optional = false)
    @Column(name = "hq_id_hq")
    private int hqIdHq;

    public UsuarioLeHqPK() {
    }

    public UsuarioLeHqPK(int usuarioIdUsuario, int hqIdHq) {
        this.usuarioIdUsuario = usuarioIdUsuario;
        this.hqIdHq = hqIdHq;
    }

    public int getUsuarioIdUsuario() {
        return usuarioIdUsuario;
    }

    public void setUsuarioIdUsuario(int usuarioIdUsuario) {
        this.usuarioIdUsuario = usuarioIdUsuario;
    }

    public int getHqIdHq() {
        return hqIdHq;
    }

    public void setHqIdHq(int hqIdHq) {
        this.hqIdHq = hqIdHq;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) usuarioIdUsuario;
        hash += (int) hqIdHq;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UsuarioLeHqPK)) {
            return false;
        }
        UsuarioLeHqPK other = (UsuarioLeHqPK) object;
        if (this.usuarioIdUsuario != other.usuarioIdUsuario) {
            return false;
        }
        if (this.hqIdHq != other.hqIdHq) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.UsuarioLeHqPK[ usuarioIdUsuario=" + usuarioIdUsuario + ", hqIdHq=" + hqIdHq + " ]";
    }
    
}
