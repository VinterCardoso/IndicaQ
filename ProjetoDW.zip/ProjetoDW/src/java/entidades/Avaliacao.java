/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author a1818058
 */
@Entity
@Table(name = "avaliacao")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Avaliacao.findAll", query = "SELECT a FROM Avaliacao a")
    , @NamedQuery(name = "Avaliacao.findByIdAvaliacao", query = "SELECT a FROM Avaliacao a WHERE a.idAvaliacao = :idAvaliacao")
    , @NamedQuery(name = "Avaliacao.findByNomeAvaliacao", query = "SELECT a FROM Avaliacao a WHERE a.nomeAvaliacao = :nomeAvaliacao")
    , @NamedQuery(name = "Avaliacao.findByComentarioAvaliacao", query = "SELECT a FROM Avaliacao a WHERE a.comentarioAvaliacao = :comentarioAvaliacao")
    , @NamedQuery(name = "Avaliacao.findByNotaAvaliacao", query = "SELECT a FROM Avaliacao a WHERE a.notaAvaliacao = :notaAvaliacao")})
public class Avaliacao implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_avaliacao")
    private Integer idAvaliacao;
    @Column(name = "nome_avaliacao")
    private String nomeAvaliacao;
    @Column(name = "comentario_avaliacao")
    private String comentarioAvaliacao;
    @Column(name = "nota_avaliacao")
    private Integer notaAvaliacao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "avaliacaoIdAvaliacao")
    private List<UsuarioLeHq> usuarioLeHqList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "avaliacaoIdAvaliacao")
    private List<Usuario> usuarioList;

    public Avaliacao() {
    }

    public Avaliacao(Integer idAvaliacao) {
        this.idAvaliacao = idAvaliacao;
    }

    public Integer getIdAvaliacao() {
        return idAvaliacao;
    }

    public void setIdAvaliacao(Integer idAvaliacao) {
        this.idAvaliacao = idAvaliacao;
    }

    public String getNomeAvaliacao() {
        return nomeAvaliacao;
    }

    public void setNomeAvaliacao(String nomeAvaliacao) {
        this.nomeAvaliacao = nomeAvaliacao;
    }

    public String getComentarioAvaliacao() {
        return comentarioAvaliacao;
    }

    public void setComentarioAvaliacao(String comentarioAvaliacao) {
        this.comentarioAvaliacao = comentarioAvaliacao;
    }

    public Integer getNotaAvaliacao() {
        return notaAvaliacao;
    }

    public void setNotaAvaliacao(Integer notaAvaliacao) {
        this.notaAvaliacao = notaAvaliacao;
    }

    @XmlTransient
    public List<UsuarioLeHq> getUsuarioLeHqList() {
        return usuarioLeHqList;
    }

    public void setUsuarioLeHqList(List<UsuarioLeHq> usuarioLeHqList) {
        this.usuarioLeHqList = usuarioLeHqList;
    }

    @XmlTransient
    public List<Usuario> getUsuarioList() {
        return usuarioList;
    }

    public void setUsuarioList(List<Usuario> usuarioList) {
        this.usuarioList = usuarioList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAvaliacao != null ? idAvaliacao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Avaliacao)) {
            return false;
        }
        Avaliacao other = (Avaliacao) object;
        if ((this.idAvaliacao == null && other.idAvaliacao != null) || (this.idAvaliacao != null && !this.idAvaliacao.equals(other.idAvaliacao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Avaliacao[ idAvaliacao=" + idAvaliacao + " ]";
    }
    
}
