package DAOs;

import entidades.Hq;
import java.util.ArrayList;
import java.util.List;

public class DAOHq extends DAOGenerico<Hq> {

    public DAOHq() {
        super(Hq.class);
    }

    public int autoIdHq() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idHq) FROM Hq e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Hq> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Hq e WHERE e.nomeHq LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Hq> listById(int id) {
        return em.createQuery("SELECT e FROM Hq e WHERE e.idHq = :id").setParameter("id", id).getResultList();
    }

    public List<Hq> listInOrderNome() {
        return em.createQuery("SELECT e FROM Hq e ORDER BY e.nomeHq").getResultList();
    }

    public List<Hq> listInOrderId() {
        return em.createQuery("SELECT e FROM Hq e ORDER BY e.idHq").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Hq> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdHq() + "-" + lf.get(i).getNomeHq());
        }
        return ls;
    }
}
