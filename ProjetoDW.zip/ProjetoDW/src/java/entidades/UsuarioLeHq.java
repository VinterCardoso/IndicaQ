/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a1818058
 */
@Entity
@Table(name = "usuario_le_hq")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UsuarioLeHq.findAll", query = "SELECT u FROM UsuarioLeHq u")
    , @NamedQuery(name = "UsuarioLeHq.findByUsuarioIdUsuario", query = "SELECT u FROM UsuarioLeHq u WHERE u.usuarioLeHqPK.usuarioIdUsuario = :usuarioIdUsuario")
    , @NamedQuery(name = "UsuarioLeHq.findByHqIdHq", query = "SELECT u FROM UsuarioLeHq u WHERE u.usuarioLeHqPK.hqIdHq = :hqIdHq")})
public class UsuarioLeHq implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UsuarioLeHqPK usuarioLeHqPK;
    @JoinColumn(name = "hq_id_hq", referencedColumnName = "id_hq", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Hq hq;
    @JoinColumn(name = "usuario_id_usuario", referencedColumnName = "id_usuario", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Usuario usuario;
    @JoinColumn(name = "avaliacao_id_avaliacao", referencedColumnName = "id_avaliacao")
    @ManyToOne(optional = false)
    private Avaliacao avaliacaoIdAvaliacao;

    public UsuarioLeHq() {
    }

    public UsuarioLeHq(UsuarioLeHqPK usuarioLeHqPK) {
        this.usuarioLeHqPK = usuarioLeHqPK;
    }

    public UsuarioLeHq(int usuarioIdUsuario, int hqIdHq) {
        this.usuarioLeHqPK = new UsuarioLeHqPK(usuarioIdUsuario, hqIdHq);
    }

    public UsuarioLeHqPK getUsuarioLeHqPK() {
        return usuarioLeHqPK;
    }

    public void setUsuarioLeHqPK(UsuarioLeHqPK usuarioLeHqPK) {
        this.usuarioLeHqPK = usuarioLeHqPK;
    }

    public Hq getHq() {
        return hq;
    }

    public void setHq(Hq hq) {
        this.hq = hq;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Avaliacao getAvaliacaoIdAvaliacao() {
        return avaliacaoIdAvaliacao;
    }

    public void setAvaliacaoIdAvaliacao(Avaliacao avaliacaoIdAvaliacao) {
        this.avaliacaoIdAvaliacao = avaliacaoIdAvaliacao;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (usuarioLeHqPK != null ? usuarioLeHqPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UsuarioLeHq)) {
            return false;
        }
        UsuarioLeHq other = (UsuarioLeHq) object;
        if ((this.usuarioLeHqPK == null && other.usuarioLeHqPK != null) || (this.usuarioLeHqPK != null && !this.usuarioLeHqPK.equals(other.usuarioLeHqPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.UsuarioLeHq[ usuarioLeHqPK=" + usuarioLeHqPK + " ]";
    }
    
}
