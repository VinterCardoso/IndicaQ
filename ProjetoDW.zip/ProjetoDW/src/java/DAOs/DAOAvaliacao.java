package DAOs;

import entidades.Avaliacao;
import java.util.ArrayList;
import java.util.List;

public class DAOAvaliacao extends DAOGenerico<Avaliacao> {

    public DAOAvaliacao() {
        super(Avaliacao.class);
    }

    public int autoIdAvaliacao() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idAvaliacao) FROM Avaliacao e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Avaliacao> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Avaliacao e WHERE e.nomeAvaliacao LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Avaliacao> listById(int id) {
        return em.createQuery("SELECT e FROM Avaliacao e WHERE e.idAvaliacao = :id").setParameter("id", id).getResultList();
    }

    public List<Avaliacao> listInOrderNome() {
        return em.createQuery("SELECT e FROM Avaliacao e ORDER BY e.nomeAvaliacao").getResultList();
    }

    public List<Avaliacao> listInOrderId() {
        return em.createQuery("SELECT e FROM Avaliacao e ORDER BY e.idAvaliacao").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Avaliacao> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdAvaliacao() + "-" + lf.get(i).getNomeAvaliacao());
        }
        return ls;
    }
}
